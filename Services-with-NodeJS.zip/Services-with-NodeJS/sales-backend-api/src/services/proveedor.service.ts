import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { ProveedorEntity } from "src/entities/proveedor.entity";
import { Repository } from "typeorm";





@Injectable()
export class ProveedorService{

    constructor(@InjectRepository(ProveedorEntity) private proveedorrepository: Repository<ProveedorEntity>){

    }

    registrar(proveedor:ProveedorEntity){

        return this.proveedorrepository.save(proveedor);
    }

    actualizar(proveedor:ProveedorEntity){
        return this.proveedorrepository.save(proveedor);
    
    }

    findall(){
        return this.proveedorrepository.find();
    }

    eliminar(id: number){
        return this.proveedorrepository.delete(id);

    }

    finId(id: number){
        return this.proveedorrepository.findBy({id});
    }

    buscarcli(rol: string){
        return this.proveedorrepository.findBy({rol})
    }


}