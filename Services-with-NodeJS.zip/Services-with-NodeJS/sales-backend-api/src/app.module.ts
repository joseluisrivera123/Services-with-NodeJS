import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UbigeoEntity } from './entities/ubigeo.entity';
import { UbigeoController } from './controllers/ubigeo.controller';
import { UbigeoService } from './services/ubigeo.service';
import { ProveedorEntity } from './entities/proveedor.entity';
import { proveedorController } from './controllers/proveedor.controller';
import { ProveedorService } from './services/proveedor.service';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      "type": "oracle",
      "host": "localhost",
      "port": 1521,
      "username": "JOSERIVERAY",
      "password": "joserivera123",
      "sid": "xe",
      "entities": [__dirname + "/**/**.entity{.ts,.js}"],
      "synchronize": false,
      "logging": true
    }),
    TypeOrmModule.forFeature([ProveedorEntity])
  ],
  controllers: [AppController, proveedorController],
  providers: [AppService, ProveedorService]
})
export class AppModule {
}