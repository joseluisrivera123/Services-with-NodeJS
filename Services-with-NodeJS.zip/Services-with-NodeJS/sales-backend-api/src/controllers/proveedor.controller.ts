import { Body, Controller, Delete, Get, Param, Post, Put } from "@nestjs/common";
import { ProveedorEntity } from "src/entities/proveedor.entity";
import { ProveedorService } from "src/services/proveedor.service";



@Controller("Proveedor")
export class proveedorController{

    constructor(private proveedorservice: ProveedorService){

    }

    @Post()
    async registrar(@Body() proveedor:ProveedorEntity): Promise<ProveedorEntity>{
        return this.proveedorservice.registrar(proveedor);
    }

    @Put()
    async actulizar(@Body() proveedor:ProveedorEntity): Promise<ProveedorEntity>{
        return this.proveedorservice.actualizar(proveedor);

    }

    @Get()
    async finall(): Promise<ProveedorEntity[]>{
        return this.proveedorservice.findall();
    }

  /**   @Get(":id")
    async finId(@Param("id") id: number): Promise<ClienteEntity[]>{
        return this.clienteservice.finId(id);
    }*/

    @Get(":rol")
    async buscarcli(@Param("rol") rol: string): Promise<ProveedorEntity[]>{
        return this.proveedorservice.buscarcli(rol);

    }


    @Delete(":id")
    async eliminar(@Param("id") id: number){
        return this.proveedorservice.eliminar(id);
    }
}