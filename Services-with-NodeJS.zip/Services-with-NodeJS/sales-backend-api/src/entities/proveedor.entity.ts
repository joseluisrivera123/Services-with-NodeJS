import { Column, Entity, PrimaryColumn } from "typeorm";

@Entity({name:'PROVEEDOR'})
export class ProveedorEntity{

    @PrimaryColumn({name: 'IDPROV', nullable:false})
    id: number;

    @Column({name:'RUCPROV', nullable:false})
    nombre:string;

    @Column({name:'RAZSOCPROV', nullable:false})
    apellido:string;

    @Column({name:'CORPROV', nullable:false})
    dni:string;

    @Column({name:'DIRPROV', nullable:false})
    celular:string;
    
    @Column({name:'CELPROV', nullable:false})
    direccion:string;
    
    @Column({name:'CODUBI', nullable:false})
    rol:string;

    @Column({name:'ESTPROV', nullable:false})
    estado:string;

}